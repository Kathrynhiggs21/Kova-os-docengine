#!/usr/bin/env bash
# ==========================================================
#  KOVA OS DocEngine — One-Line Installer / Bootstrap Script
# ==========================================================

set -e
ZIPFILE=${1:-KOVA_OS_DocEngine_Full_$(date +%F).zip}
TARGET_DIR="kova-os-docengine"

echo "🧭 KOVA OS DocEngine — Installer"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

if [ ! -f "$ZIPFILE" ]; then
  echo "❌ Cannot find $ZIPFILE"
  echo "Usage: ./install.sh <zipfile>"
  echo ""
  echo "If no ZIP exists, run 'npm install && npm run dev' directly."
  exit 1
fi

echo "📦 Extracting $ZIPFILE ..."
unzip -q "$ZIPFILE" -d ./

if [ ! -d "$TARGET_DIR" ]; then
  echo "⚠️  Folder '$TARGET_DIR' not found after extraction."
  echo "Continuing with current directory..."
  TARGET_DIR="."
fi

cd "$TARGET_DIR"

echo "⚙️  Installing dependencies..."
npm install --silent

echo "🚀 Starting local dev server..."
npm run dev