#!/usr/bin/env bash
# =====================================================
#  KOVA OS Document Engine — Deploy + Notify Utility
#  (Final version with live link inclusion)
# =====================================================

set -e

APP_NAME="kova-os-docengine"
DATE=$(date +"%Y-%m-%d")
LATEST_ZIP=$(ls -t KOVA_OS_DocEngine_build-v*.zip 2>/dev/null | head -1)

if [ -z "$LATEST_ZIP" ]; then
  echo "❌ No ZIP build found. Run ./build.sh first."
  exit 1
fi

# ---- CONFIG ----
NETLIFY_SITE_ID="${NETLIFY_SITE_ID:-}"
NETLIFY_AUTH_TOKEN="${NETLIFY_AUTH_TOKEN:-}"
GDRIVE_FOLDER_ID="${GDRIVE_FOLDER_ID:-}"
GOOGLE_DRIVE_TOKEN="${GOOGLE_DRIVE_TOKEN:-}"
WEBHOOK_URL="${WEBHOOK_URL:-}"

NETLIFY_URL=""
DRIVE_URL=""

# ---- Deploy to Netlify ----
if [ -n "$NETLIFY_SITE_ID" ] && [ -n "$NETLIFY_AUTH_TOKEN" ]; then
  echo "🌐 Deploying to Netlify site $NETLIFY_SITE_ID..."
  NETLIFY_RESPONSE=$(curl -s -H "Content-Type: application/zip" \
                           -H "Authorization: Bearer $NETLIFY_AUTH_TOKEN" \
                           --data-binary @"$LATEST_ZIP" \
                           "https://api.netlify.com/api/v1/sites/$NETLIFY_SITE_ID/deploys")
  NETLIFY_URL=$(echo "$NETLIFY_RESPONSE" | grep -o '"url":"[^"]*' | head -1 | cut -d'"' -f4)
  echo "✅ Netlify deploy initiated: $NETLIFY_URL"
else
  echo "⚠️  Netlify credentials missing — skipping Netlify deploy."
fi

# ---- Upload to Google Drive ----
if [ -n "$GDRIVE_FOLDER_ID" ] && [ -n "$GOOGLE_DRIVE_TOKEN" ]; then
  echo "☁️  Uploading $LATEST_ZIP to Google Drive..."
  DRIVE_RESPONSE=$(curl -s -X POST \
       -L -H "Authorization: Bearer $GOOGLE_DRIVE_TOKEN" \
       -F "metadata={name :'$LATEST_ZIP', parents :['$GDRIVE_FOLDER_ID']};type=application/json;charset=UTF-8" \
       -F "file=@$LATEST_ZIP;type=application/zip" \
       "https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart")
  DRIVE_ID=$(echo "$DRIVE_RESPONSE" | grep -o '"id":"[^"]*' | head -1 | cut -d'"' -f4)
  DRIVE_URL="https://drive.google.com/file/d/${DRIVE_ID}/view"
  echo "✅ Google Drive upload complete: $DRIVE_URL"
else
  echo "⚠️  Google Drive credentials missing — skipping upload."
fi

# ---- Notify via Webhook ----
if [ -n "$WEBHOOK_URL" ]; then
  echo "📣 Sending webhook notification..."
  SUMMARY="✅ *KOVA OS DocEngine* build deployed on ${DATE}"
  DETAILS="File: \`${LATEST_ZIP}\`"
  LINKS=""

  [ -n "$NETLIFY_URL" ] && LINKS="${LINKS}\n🌐 [View on Netlify](${NETLIFY_URL})"
  [ -n "$DRIVE_URL" ] && LINKS="${LINKS}\n☁️ [Download ZIP on Drive](${DRIVE_URL})"

  MSG="${SUMMARY}\n${DETAILS}${LINKS}\nStatus: Live 🌈"

  # Try to use jq if available, otherwise use simple format
  if command -v jq &> /dev/null; then
    PAYLOAD=$(jq -n --arg content "$MSG" '{text:$content,content:$content}')
  else
    PAYLOAD="{\"text\":\"$MSG\",\"content\":\"$MSG\"}"
  fi
  
  curl -s -X POST -H "Content-Type: application/json" -d "$PAYLOAD" "$WEBHOOK_URL" \
    && echo "✅ Notification sent."
else
  echo "⚠️  No webhook configured — skipping notification."
fi

echo "🎉 Deployment complete."