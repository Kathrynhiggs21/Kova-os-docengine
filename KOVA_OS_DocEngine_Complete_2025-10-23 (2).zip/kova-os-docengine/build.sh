#!/usr/bin/env bash
# ============================================================
#  KOVA OS Document Engine — Full Build, Zip, and Version Tool
# ============================================================

set -e

# -------- CONFIG --------
APP_NAME="kova-os-docengine"
DATE=$(date +"%Y-%m-%d")

# -------- GET CURRENT VERSION --------
CURRENT_VERSION=$(grep '"version"' package.json | head -1 | sed -E 's/[^0-9.]//g')
IFS='.' read -r MAJOR MINOR PATCH <<< "$CURRENT_VERSION"
NEW_VERSION="${MAJOR}.$((MINOR+1)).0"

TAG="build-v${NEW_VERSION}-${DATE}"
OUTFILE="KOVA_OS_DocEngine_${TAG}.zip"

# -------- PREPARE BUILD --------
echo "🔧 Cleaning previous build..."
rm -rf dist "$OUTFILE" 2>/dev/null || true

echo "📦 Installing dependencies..."
npm install --silent

# -------- BUILD PROJECT --------
echo "🚀 Building project..."
npm run build

# -------- CREATE ZIP --------
echo "🧩 Creating ZIP archive..."
zip -r "$OUTFILE" dist/ public/ src/ package.json vite.config.js index.html README.md build.sh -x "*.DS_Store"

# -------- VERSION BUMP --------
echo "🔢 Bumping version: ${CURRENT_VERSION} → ${NEW_VERSION}"
sed -i "s/\"version\": \"${CURRENT_VERSION}\"/\"version\": \"${NEW_VERSION}\"/" package.json

# -------- CHANGELOG UPDATE --------
echo "🗒️  Updating CHANGELOG.md..."
echo "- ${DATE}: Auto build ${TAG}" >> CHANGELOG.md

# -------- GIT OPERATIONS --------
if git rev-parse --git-dir > /dev/null 2>&1; then
  echo "🏷️  Committing and tagging..."
  git add -A
  git commit -m "Auto build ${TAG}" || echo "ℹ️  No changes to commit."
  git tag -a "${TAG}" -m "KOVA OS DocEngine build ${NEW_VERSION} (${DATE})"
  git push --follow-tags || echo "⚠️  Push skipped (check remote permissions)."
else
  echo "⚠️  Not a Git repository — skipping Git tagging."
fi

# -------- DONE --------
echo "✅ Build complete!"
echo "📁 Created: ${OUTFILE}"
echo "📌 Version bumped to: v${NEW_VERSION}"