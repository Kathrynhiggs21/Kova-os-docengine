#!/usr/bin/env bash
# =========================================================
#  KOVA OS Document Engine — Rollback Utility
# =========================================================

set -e

APP_NAME="kova-os-docengine"

# -------- Locate previous build --------
LATEST=$(ls -t KOVA_OS_DocEngine_build-v*.zip 2>/dev/null | head -2 | tail -1)
if [ -z "$LATEST" ]; then
  echo "❌ No previous build archive found. Nothing to roll back to."
  exit 1
fi

echo "⏪ Rolling back to previous build: $LATEST"

# -------- Clean current dist --------
rm -rf dist || true

# -------- Extract previous archive --------
unzip -o "$LATEST" -d . >/dev/null
echo "📦 Restored files from $LATEST"

# -------- Reset version --------
if [ -f package.json ]; then
  PREV_VERSION=$(echo "$LATEST" | grep -o 'build-v[0-9.]*' | sed 's/build-v//')
  echo "🔢 Reverting package.json version to ${PREV_VERSION}"
  sed -i "s/\"version\": \".*\"/\"version\": \"${PREV_VERSION}\"/" package.json
fi

# -------- Git rollback (optional) --------
if git rev-parse --git-dir > /dev/null 2>&1; then
  echo "🔁 Resetting Git HEAD to previous commit..."
  git reset --hard HEAD~1 || echo "⚠️  Could not reset Git HEAD (check commit history)."
else
  echo "⚠️  Not a Git repository — skipping Git rollback."
fi

# -------- Confirm done --------
echo "✅ Rollback complete."
echo "Previous build restored from: $LATEST"