import { useState } from "react";
import { motion } from "framer-motion";
import ControlPanel from "./components/ControlPanel.jsx";
import OrbScene from "./components/OrbScene.jsx";
import WaveBackground from "./components/WaveBackground.jsx";
import MarkdownViewer from "./components/MarkdownViewer.jsx";
import AppendixCards from "./components/AppendixCards.jsx";

export default function App() {
  const [theme, setTheme] = useState("prismatic");
  const [orbType, setOrbType] = useState("liquid");
  const [waveSpeed, setWaveSpeed] = useState("slow");

  return (
    <div className={`relative min-h-screen overflow-hidden theme-${theme}`}>
      <WaveBackground speed={waveSpeed} />
      <OrbScene theme={theme} orbType={orbType} />
      <div className="relative z-10 p-4 max-w-5xl mx-auto">
        <MarkdownViewer />
        <AppendixCards />
      </div>
      <ControlPanel
        theme={theme}
        setTheme={setTheme}
        orbType={orbType}
        setOrbType={setOrbType}
        waveSpeed={waveSpeed}
        setWaveSpeed={setWaveSpeed}
      />
    </div>
  );
}