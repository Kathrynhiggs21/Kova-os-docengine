export default function ControlPanel({
  theme,
  setTheme,
  orbType,
  setOrbType,
  waveSpeed,
  setWaveSpeed,
}) {
  const handleExportPDF = () => {
    // Simple print trigger for PDF export
    window.print();
  };

  return (
    <div className="fixed bottom-4 right-4 bg-neutral-900/70 backdrop-blur-md rounded-2xl p-4 text-sm space-y-2 shadow-xl border border-white/10">
      <div>
        <label className="block text-gray-400">Theme</label>
        <select
          value={theme}
          onChange={(e) => setTheme(e.target.value)}
          className="bg-neutral-800 rounded px-2 py-1 w-full text-white"
        >
          <option value="prismatic">Prismatic</option>
          <option value="aurora">Aurora</option>
          <option value="darkmono">DarkMono</option>
        </select>
      </div>
      <div>
        <label className="block text-gray-400">Orb Type</label>
        <select
          value={orbType}
          onChange={(e) => setOrbType(e.target.value)}
          className="bg-neutral-800 rounded px-2 py-1 w-full text-white"
        >
          <option value="liquid">Liquid</option>
          <option value="glass">Glass</option>
          <option value="metallic">Metallic</option>
        </select>
      </div>
      <div>
        <label className="block text-gray-400">Wave Speed</label>
        <select
          value={waveSpeed}
          onChange={(e) => setWaveSpeed(e.target.value)}
          className="bg-neutral-800 rounded px-2 py-1 w-full text-white"
        >
          <option value="none">None</option>
          <option value="slow">Slow</option>
          <option value="medium">Medium</option>
          <option value="fast">Fast</option>
        </select>
      </div>
      <button
        onClick={handleExportPDF}
        className="w-full mt-2 bg-gradient-to-r from-cyan-400 to-pink-500 text-white py-1 rounded font-medium hover:from-cyan-500 hover:to-pink-600 transition-all"
      >
        Export PDF
      </button>
    </div>
  );
}