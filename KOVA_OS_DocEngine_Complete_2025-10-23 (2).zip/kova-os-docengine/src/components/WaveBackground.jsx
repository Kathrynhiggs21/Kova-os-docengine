import { motion } from "framer-motion";

export default function WaveBackground({ speed }) {
  const animSpeed = { none: 0, slow: 20, medium: 10, fast: 5 }[speed];
  
  if (animSpeed === 0) {
    return null; // No animation when speed is "none"
  }
  
  return (
    <div className="absolute inset-0 overflow-hidden -z-10">
      {[...Array(3)].map((_, i) => (
        <motion.div
          key={i}
          animate={{
            x: ["0%", "100%"],
          }}
          transition={{
            duration: animSpeed * (i + 1),
            repeat: Infinity,
            ease: "linear",
          }}
          className={`absolute w-[200%] h-full opacity-30 bg-gradient-to-r from-cyan-500 via-pink-500 to-purple-500 rounded-full blur-3xl`}
          style={{ top: `${i * 33}%` }}
        />
      ))}
    </div>
  );
}