import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { useEffect, useState } from "react";

export default function MarkdownViewer() {
  const [content, setContent] = useState("");

  useEffect(() => {
    // Try to fetch the markdown document
    fetch("/docs/KOVA_OS_Implementation_Plan_v1.0.md")
      .then((r) => {
        if (!r.ok) throw new Error("File not found");
        return r.text();
      })
      .then(setContent)
      .catch(() => {
        // Use default content if file not found
        setContent(`# KOVA OS Implementation Plan

## 🎯 Executive Summary
KOVA OS (Katy's Organizational Voice Assistant) is a comprehensive automation platform designed to unify 30+ digital platforms into a single intelligent hub.

## 🏗️ System Architecture
- **Core Components**: KOVA Core, KOVA Lens, KOVA Writing, Nova Research
- **Integration Layer**: Google Workspace, GitHub, AI Services, Automation Tools
- **Security Framework**: SOPS/age encryption, OAuth 2.0, DNSSEC

## 📊 Current Status
- **Completion**: ~67%
- **Active Applications**: 4 (KOVA Core, Milton, theCenter, Reagan)
- **Platform Integrations**: 15/30 complete
- **Documentation**: Comprehensive

## 🚀 Next Steps
1. Complete critical security implementation
2. Consolidate fragmented work across platforms
3. Establish master orchestration layer
4. Deploy mobile PWA for Android

## 🔗 Resources
- **Main Hub**: kovaos.com
- **Repository**: GitHub (Kathrynhiggs21/kathiggs)
- **Contact**: spear.cpt@gmail.com

---
*"Your life. Sorted."* — KOVA AI`);
      });
  }, []);

  return (
    <div className="prose prose-invert max-w-none prose-headings:text-cyan-400 prose-a:text-pink-400 prose-strong:text-white">
      <ReactMarkdown remarkPlugins={[remarkGfm]}>{content}</ReactMarkdown>
    </div>
  );
}