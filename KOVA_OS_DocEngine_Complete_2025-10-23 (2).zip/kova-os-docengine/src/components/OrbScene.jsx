import { useEffect, useRef } from "react";
import * as THREE from "three";

export default function OrbScene({ theme, orbType }) {
  const mountRef = useRef(null);

  useEffect(() => {
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, window.innerWidth / 400, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
    renderer.setSize(window.innerWidth, 400);
    renderer.setPixelRatio(window.devicePixelRatio);
    
    if (mountRef.current) {
      mountRef.current.appendChild(renderer.domElement);
    }

    // Create the orb geometry
    const geometry = new THREE.SphereGeometry(2, 64, 64);
    
    // Configure material based on orb type
    const materialConfig = {
      color: new THREE.Color(theme === "aurora" ? 0xff88ff : theme === "darkmono" ? 0x666666 : 0x88ffff),
      transmission: orbType === "glass" ? 0.9 : 0.3,
      roughness: orbType === "metallic" ? 0.1 : 0.4,
      metalness: orbType === "metallic" ? 1 : 0.2,
      clearcoat: 1,
      clearcoatRoughness: 0.1,
    };
    
    const material = new THREE.MeshPhysicalMaterial(materialConfig);
    const sphere = new THREE.Mesh(geometry, material);
    scene.add(sphere);
    
    // Position camera
    camera.position.z = 5;

    // Add lighting
    const light1 = new THREE.PointLight(0xffffff, 1.2);
    light1.position.set(10, 10, 10);
    scene.add(light1);
    
    const light2 = new THREE.PointLight(0xff00ff, 0.4);
    light2.position.set(-10, -10, 10);
    scene.add(light2);
    
    const ambientLight = new THREE.AmbientLight(0x404040, 0.5);
    scene.add(ambientLight);

    // Animation loop
    function animate() {
      requestAnimationFrame(animate);
      sphere.rotation.y += 0.005;
      sphere.rotation.x += 0.002;
      renderer.render(scene, camera);
    }
    animate();

    // Handle window resize
    function handleResize() {
      camera.aspect = window.innerWidth / 400;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, 400);
    }
    window.addEventListener('resize', handleResize);

    // Cleanup
    return () => {
      window.removeEventListener('resize', handleResize);
      if (mountRef.current && renderer.domElement) {
        mountRef.current.removeChild(renderer.domElement);
      }
      renderer.dispose();
      geometry.dispose();
      material.dispose();
    };
  }, [theme, orbType]);

  return <div ref={mountRef} className="w-full h-[400px]" />;
}