import { useEffect, useState } from "react";

export default function AppendixCards() {
  const [inventory, setInventory] = useState([]);
  const [secrets, setSecrets] = useState([]);
  const [tasks, setTasks] = useState([]);

  useEffect(() => {
    // Fetch inventory data
    fetch("/data/inventory.json")
      .then(r => r.json())
      .then(setInventory)
      .catch(() => {
        // Use default data if not found
        setInventory([
          { name: "Core System Setup", status: "Complete" },
          { name: "Applications Integration", status: "In Progress" },
          { name: "GitHub & Codespaces", status: "Active" },
          { name: "Security Policies", status: "Critical" },
          { name: "Compliance (HIPAA)", status: "Pending" }
        ]);
      });

    // Fetch secrets schema
    fetch("/data/secrets.json")
      .then(r => r.json())
      .then(setSecrets)
      .catch(() => {
        // Use default schema
        setSecrets([
          { key: "API_KEYS_STORED_IN", value: "Google Secret Manager" },
          { key: "OAUTH_METHOD", value: "SOPS + age" },
          { key: "2FA_PROVIDER", value: "Twilio" },
          { key: "ENCRYPTION", value: "AES-256" },
          { key: "CERT_MANAGEMENT", value: "Let's Encrypt" }
        ]);
      });

    // Parse uploaded tasks data
    const tasksData = [
      { task_id: "T001", title: "Complete Security Implementation", priority: "Critical", status: "In Progress" },
      { task_id: "T002", title: "Consolidate AI Platform Work", priority: "High", status: "Planning" },
      { task_id: "T003", title: "Deploy Mobile PWA", priority: "Medium", status: "Development" }
    ];
    setTasks(tasksData);
  }, []);

  return (
    <section className="mt-16 mb-32">
      <h2 className="text-3xl font-bold text-center mb-8 bg-gradient-to-r from-cyan-400 to-pink-500 bg-clip-text text-transparent">
        System Appendices
      </h2>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        <DataCard title="Inventory Workbook" data={inventory} color="cyan" icon="📋" />
        <DataCard title="Security Matrix" data={secrets} color="violet" icon="🔐" />
        <DataCard title="Active Tasks" data={tasks} color="pink" icon="🎯" />
      </div>
    </section>
  );
}

function DataCard({ title, data, color, icon }) {
  const borderColors = {
    cyan: "border-cyan-500/50",
    violet: "border-violet-500/50",
    pink: "border-pink-500/50"
  };

  const glowColors = {
    cyan: "0 0 20px rgba(0,255,255,0.2)",
    violet: "0 0 20px rgba(139,92,246,0.2)",
    pink: "0 0 20px rgba(236,72,153,0.2)"
  };

  return (
    <div 
      className={`holo-card ${borderColors[color]} p-6 rounded-2xl backdrop-blur-md bg-white/5`}
      style={{ 
        boxShadow: glowColors[color],
        border: "1px solid rgba(255, 255, 255, 0.1)"
      }}
    >
      <h3 className="text-xl font-semibold mb-4 flex items-center gap-2">
        <span className="text-2xl">{icon}</span>
        {title}
      </h3>
      <div className="overflow-y-auto max-h-64 text-sm space-y-2">
        {data && data.length ? (
          <ul className="space-y-2">
            {data.map((item, i) => (
              <li key={i} className="flex items-start gap-2 p-2 rounded hover:bg-white/5 transition-colors">
                <span className="text-cyan-400 mt-1">•</span>
                <div className="flex-1">
                  {item.name || item.key || item.title || JSON.stringify(item)}
                  {item.value && (
                    <span className="text-gray-400 ml-2">→ {item.value}</span>
                  )}
                  {item.status && (
                    <span className={`ml-2 text-xs px-2 py-0.5 rounded ${
                      item.status === 'Critical' ? 'bg-red-500/20 text-red-400' :
                      item.status === 'Complete' ? 'bg-green-500/20 text-green-400' :
                      item.status === 'Active' ? 'bg-blue-500/20 text-blue-400' :
                      'bg-yellow-500/20 text-yellow-400'
                    }`}>
                      {item.status}
                    </span>
                  )}
                </div>
              </li>
            ))}
          </ul>
        ) : (
          <p className="italic opacity-50">Loading data...</p>
        )}
      </div>
    </div>
  );
}