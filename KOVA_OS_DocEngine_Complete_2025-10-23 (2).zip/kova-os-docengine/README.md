<div align="center">

# 🪩 **KOVA OS DocEngine — NeoPrism Edition**

### *Autonomous Intelligence Framework for Personal Ecosystem Management*  
✨ _"You clearly need me."_ ✨  

![orb divider](https://img.shields.io/badge/—-💎—-00000000?style=for-the-badge)

</div>

---

## 🚀 Quick Start

KOVA OS DocEngine is a **React + Three.js NeoPrism environment** that renders, builds, and deploys your branded KOVA documentation system.

### 🔧 Local Setup
```bash
npm install
npm run dev        # open http://localhost:5173
```

---

## ⚙️ Automation Workflow

| Script | Description |
|--------|-------------|
| 💠 `./build.sh` | Build + zip + version bump + Git-tag |
| 🌐 `./deploy.sh` | Deploy to Netlify / Drive + send Slack / Discord notice |
| ♻️ `./rollback.sh` | Restore previous stable build |
| 🧭 `./status.sh` | Show current version, tag, and latest ZIP info |
| 📦 `./install.sh` | One-line setup from ZIP archive |

---

## 🗃️ Full Archive

To package the entire engine as one portable bundle:

```bash
cd ..
zip -r KOVA_OS_DocEngine_Full_$(date +%F).zip kova-os-docengine/
```

---

## 🪄 Results

- 🌈 **Live NeoPrism interface** (3-D orb, liquid waves)
- 📦 **Static + interactive outputs** (PDF / HTML / Markdown)
- 🔁 **Automated CI/CD cycle** with versioning, rollback, and notifications

---

## 📊 Features

### Core Components
- **3D Orb Visualization** - Three.js powered holographic orb with multiple material types
- **Wave Backgrounds** - Animated gradient waves with adjustable speed
- **Markdown Viewer** - Full markdown support with GFM extensions
- **Appendix Cards** - Holographic data cards for inventory and system status
- **Control Panel** - Real-time theme and animation controls

### Themes
- **Prismatic** - Cyan to pink gradient with orange accents
- **Aurora** - Soft pastel gradients  
- **DarkMono** - Monochromatic professional theme

### Automation Scripts
- Version bumping and changelog generation
- Git tagging and commit automation
- Netlify deployment integration
- Google Drive backup support
- Slack/Discord webhook notifications
- One-click rollback system

---

## 🔧 Configuration

### Environment Variables
```bash
export NETLIFY_SITE_ID="your-site-id"
export NETLIFY_AUTH_TOKEN="your-token"
export GDRIVE_FOLDER_ID="your-folder-id"
export GOOGLE_DRIVE_TOKEN="ya29.a0AR..."
export WEBHOOK_URL="https://hooks.slack.com/services/XXX"
```

### Project Structure
```
kova-os-docengine/
├── src/
│   ├── components/     # React components
│   ├── index.css       # Styles
│   ├── main.jsx        # Entry point
│   └── App.jsx         # Main app
├── public/
│   ├── docs/          # Markdown documentation
│   └── data/          # JSON data files
├── build.sh           # Build automation
├── deploy.sh          # Deploy automation
├── rollback.sh        # Rollback utility
├── status.sh          # Status dashboard
└── install.sh         # Installer script
```

---

## 🌐 Integration

### KOVA Ecosystem
This DocEngine integrates with the broader KOVA AI system:
- **KOVA Core** - Central AI functionality
- **KOVA Lens** - Visual recognition
- **KOVA Writing** - Content generation
- **Nova Research** - Web research

### Platform Support
- Google Workspace integration
- GitHub Actions CI/CD
- Vercel/Netlify deployment
- Make.com automation
- Twilio notifications

---

## 📝 License

© 2025 KOVA AI for Katy Higgs — All rights reserved.

<div align="center">

💫 **Prepared by KOVA AI on behalf of Katy Higgs** 

*Contact: spear.cpt@gmail.com*

</div>