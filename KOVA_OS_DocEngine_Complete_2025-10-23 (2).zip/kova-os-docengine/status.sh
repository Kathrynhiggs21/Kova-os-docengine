#!/usr/bin/env bash
# ======================================================
#  KOVA OS Document Engine — Status Dashboard
# ======================================================

APP_NAME="kova-os-docengine"

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo " 🧠  KOVA OS Document Engine Status"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

if [ -f package.json ]; then
  VERSION=$(grep '"version"' package.json | head -1 | sed -E 's/[^0-9.]//g')
  echo "📦  Version:      v$VERSION"
else
  echo "📦  Version:      (package.json not found)"
fi

if git rev-parse --git-dir > /dev/null 2>&1; then
  TAG=$(git describe --tags --abbrev=0 2>/dev/null || echo "no tag")
  LAST=$(git log -1 --format=%cd --date=short 2>/dev/null)
  echo "🏷️   Latest tag:   $TAG"
  echo "🗓️   Last commit:  $LAST"
else
  echo "🏷️   Git:          (not initialized)"
fi

LATEST_ZIP=$(ls -t KOVA_OS_DocEngine_build-v*.zip 2>/dev/null | head -1)
if [ -n "$LATEST_ZIP" ]; then
  SIZE=$(du -h "$LATEST_ZIP" | cut -f1)
  DATE=$(stat -c %y "$LATEST_ZIP" 2>/dev/null | cut -d' ' -f1 || date -r "$LATEST_ZIP" +%Y-%m-%d 2>/dev/null)
  echo "📁  Latest ZIP:   $LATEST_ZIP  ($SIZE, $DATE)"
else
  echo "📁  Latest ZIP:   none yet"
fi

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "💡  Commands:"
echo "   ./build.sh     → build & tag"
echo "   ./deploy.sh    → deploy & notify"
echo "   ./rollback.sh  → restore previous build"
echo "   ./status.sh    → show this dashboard"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"